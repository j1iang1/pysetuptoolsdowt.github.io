def pwsnum():
    import random
    numberOfPassword = int(input('要生成几个密码？'))
    lengthOfPassword = int(input('要生成几位数的密码？'))

    sourceOfPassword = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@£$%^&*().,?0123456789'

    for i in range(numberOfPassword):
        password = ''
        for j in range(lengthOfPassword):
            password += random.choice(sourceOfPassword)
        print(password)
    return






def sangeshuda(num1,num2,num3):
    max=num1
    if max<num2:
        max=num2
    if max<num3:
        max=num3
    print('最大值为:',max)
    return



def towweima(url):
    import qrcode
    img = qrcode.make(url)
    img.save('qrcode.jpg')
    print('您的二维码以放入文件夹内')
    return


